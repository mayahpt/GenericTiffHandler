| Software              | Version                                              |
| --------              | -------                                              |
| **OpenSlide**         | **4.0.0**                                            |
| cairo                 | 1.18.0-1                                             |
| gdk-pixbuf            | 2.42.10-1                                            |
| glib                  | 2.80.0-1                                             |
| libdicom              | 1.1.0-1                                              |
| libffi                | 3.4.4-3                                              |
| libjpeg-turbo         | 3.0.2-1                                              |
| libpng                | 1.6.43-1                                             |
| libtiff               | 4.6.0-1                                              |
| libxml2               | 2.12.6-1                                             |
| OpenJPEG              | 2.5.2-2                                              |
| PCRE2                 | 10.43-1                                              |
| pixman                | 0.43.4-1                                             |
| proxy-libintl         | 0.4-1                                                |
| SQLite                | 3.45.3-1                                             |
| uthash                | 2.3.0                                                |
| zlib                  | 1.3.1-1                                              |
| _Binutils_            | _GNU ld (Gentoo 2.42 p3) 2.42.0_                     |
| _GCC_                 | _(Gentoo 13.2.1_p20240210 p14) 13.2.1 20240210_      |
| _MinGW-w64_           | _11.0.0_                                             |
